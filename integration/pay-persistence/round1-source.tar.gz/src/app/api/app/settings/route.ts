import { z } from 'zod';
import { AtomicAmountSchema } from '../../../../modules/authority/atomic-money';
import { appRuntime } from '@/modules/app/app-runtime';
import { managementRoute } from '@/modules/app/management-auth';
import { smallJson } from '@/modules/http/local-request';

const Input = z.union([
  z.object({ dailyLimit: z.string().refine(value => AtomicAmountSchema.safeParse(value).success, 'Invalid atomic amount').nullable() }).strict(),
  z.object({ paused: z.boolean() }).strict(),
]);
export const runtime = 'nodejs';
export async function PUT(request: Request) {
  return managementRoute(request, true, async request => {
    const input = Input.parse(await smallJson(request));
    const settings = 'dailyLimit' in input ? appRuntime().setDailyLimit(input.dailyLimit) : appRuntime().setPaused(input.paused);
    return Response.json({ settings });
  });
}
